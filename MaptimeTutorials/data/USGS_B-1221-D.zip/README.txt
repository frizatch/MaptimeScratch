This georeferenced image was downloaded from the USGS/AASG National Geologic Map Database, on Fri Jun 21 18:49:52 2019 (GMT).
Georeferencing and projection information are provided in the USGS_B-1221-D_1.tif.aux.xml file (see also the USGS_B-1221-D_1.tif.txt).

TITLE = Geology of the Eldorado Springs quadrangle, Boulder and Jefferson Counties, Colorado
AUTHOR(S) = Wells, J.D.
PUBLISHER = U.S. Geological Survey
SERIES NAME = Bulletin
SERIES NUMBER = 1221-D
PUBLICATION DATE = 1967
SCALE = 1:24,000
URL = /Prodesc/proddesc_21289.htm
