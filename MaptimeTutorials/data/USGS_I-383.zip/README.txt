This georeferenced image was downloaded from the USGS/AASG National Geologic Map Database, on Fri Jun 21 18:50:08 2019 (GMT).
Georeferencing and projection information are provided in the USGS_I-383_1.tif.aux.xml file (see also the USGS_I-383_1.tif.txt).

TITLE = Preliminary geologic map of the Eldorado Springs quadrangle, Boulder and Jefferson Counties, Colorado
AUTHOR(S) = Wells, J.D.
PUBLISHER = U.S. Geological Survey
SERIES NAME = Miscellaneous Geologic Investigations Map
SERIES NUMBER = I-383
PUBLICATION DATE = 1963
SCALE = 1:24,000
URL = /Prodesc/proddesc_1658.htm
